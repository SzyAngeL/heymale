<!DOCTYPE html>
<html lang="en">

<head>
  <!-- basic -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- mobile metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="initial-scale=1, maximum-scale=1">
  <!-- site metas -->
  <title> HEY MALE</title>
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- fevicon -->
  <link rel="icon" href="images/fevicon.png" type="image/gif" />
  <!-- bootstrap css -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- style css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- Responsive-->
  <link rel="stylesheet" href="css/responsive.css">  
  <!-- Scrollbar Custom CSS -->
  <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
  <!-- Tweaks for older IEs-->
  <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<!-- body -->

<body class="main-layout" bgcolor="#CCCCCC">
  <!-- loader  -->
  <div class="loader_bg">
    <div class="loader"><img src="images/loading.gif" alt="#" /></div>
  </div>
  <!-- end loader -->
<div class="sidebar">
    <div class="logo-details">
        <div class="logo_name">HEY MALE</div>
        <i class='bx bx-menu bx-flip-horizontal' id="btn" style='color:#fffefe'></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="#">
          
          <span class="links_name">HOT ITEMS</span>
        </a>
      </li>
      <li>
       <a href="#">
        
         <span class="links_name">AVAILABLE ITEMS</span>
       </a>
     </li>
     <li>
       <a href="#">
         
         <span class="links_name">Collection</span>
       </a>
     </li>
     
    </ul>
  </div>
  <script>
  let sidebar = document.querySelector(".sidebar");
  let closeBtn = document.querySelector("#btn");
  let searchBtn = document.querySelector(".bx-search");

  closeBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("open");
    menuBtnChange();//calling the function(optional)
  });

  searchBtn.addEventListener("click", ()=>{ // Sidebar open when you click on the search iocn
    sidebar.classList.toggle("open");
    menuBtnChange(); //calling the function(optional)
  });

  // following are the code to change sidebar button(optional)
  function menuBtnChange() {
   if(sidebar.classList.contains("open")){
     closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
   }else {
     closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
   }
  }
  </script>
  <!-- header -->
  

<header>
    <!-- header inner -->
    <div class="header-top">
        <div class="container">
          <div class="row">
		  		<div class="main-menu">
				  	<ul class="menu-area-main">
						<li class="menu-area1"><a href="#"> <img src="https://spaces.ilfen.co/assets/image/produk/HEYMALE_LOGO-013.png" alt="#" width="150" height="100" /> </a> </li>
					</ul>
				</div>
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-9">
              <div class="menu-area">
                <div class="main-menu1">
					<div class="dropdown">
  						<button class="btn bg-transparent dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:#CCCCCC">
						<i class='bx bxs-shopping-bags' style="color:#CCCCCC"></i>
  						</button>
  							<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    							<a class="dropdown-item" href="/login1">Belanja</a>
								<a class="dropdown-item" href="/login1/register.html">Keranjang</a>
    							<a class="dropdown-item" href="#">Help</a>
  							</div>
					</div>  
               </div> <div class="main-menu3"><a href="login1/index.html" style="color:#CCCCCC">Login</a> &nbsp;<a href="register.html" style="color:#CCCCCC">Register </a> </div>
             </div>
           </div>
         </div>
     </div>
     <!-- end header inner -->

     <!-- end header -->
     <section class="slider_section">
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">

            <div class="container">
              <div class="carousel-caption">
                <div class="row">
                  <div class="col-md-12">
                    <div class="text-bg">
                     <div class="text-bg">
                        
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
     

   </div>
    
  

</section>
</div>
</header>

<!-- about  -->
<div id="about" class="about">
  <div class="container">
          <h2></h2>
           <table width="100%" border="0" align="center" cellspacing="10">
            <tr>
              <td>
			  	 <img style="width: 260px; height: 450px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/D1366012-6A0C-4D0E-A57A-0EE0C6781B8F.jpeg" alt="img" class="category-img">
				 <img style="width: 260px; height: 450px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/188F1A6B-E761-4854-8161-C397EF801C28.jpeg" alt="img" class="category-img">
				 <img style="width: 260px; height: 450px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/C9CE8265-35B1-45BB-98BC-5DF287540258.jpeg" alt="img" class="category-img">
			  </td>
            </tr>
    </table>
      	<center><a href="#" class="active"><input type="submit" name="Submit" value="View All"></a> </center>
      	
  </div>
</div>
<!-- end abouts -->

<!-- content bot -->
<div class="content-bot">
      <div class="header">
        <div class="container">
          <div class="row">
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col logo_section">
              <div class="full">
                <div class="center-desk">
                  <div class="logo">
                    <a href="index.php">Hey Male</a> </div>
                </div>
              </div>
            </div>
          </div>
         </div>
       </div>
     </div>
<!-- end content -->
<!-- content2  -->
<div id="about" class="about">
  <div class="container">
          <h2></h2>
           <table width="100%" border="0" align="center" cellspacing="10">
            <tr>
              <td>
				 <a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('img1','','https://spaces.ilfen.co/assets/image/produk/188F1A6B-E761-4854-8161-C397EF801C28.jpeg',0)">
				 <img style="width: 300px; height: 500px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/D1366012-6A0C-4D0E-A57A-0EE0C6781B8F.jpeg" alt="img" class="category-img" name="img1"> </a>
				 
				 <img style="width: 300px; height: 500px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/188F1A6B-E761-4854-8161-C397EF801C28.jpeg" alt="img" class="category-img">
				 
				 <img style="width: 300px; height: 500px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/C9CE8265-35B1-45BB-98BC-5DF287540258.jpeg" alt="img" class="category-img">
				 
				 <img style="width: 300px; height: 500px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/D1366012-6A0C-4D0E-A57A-0EE0C6781B8F.jpeg" alt="img" class="category-img">
				 
				 <img style="width: 300px; height: 500px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/188F1A6B-E761-4854-8161-C397EF801C28.jpeg" alt="img" class="category-img">
				 
				 <img style="width: 300px; height: 500px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/C9CE8265-35B1-45BB-98BC-5DF287540258.jpeg" alt="img" class="category-img">
				 
				 <img style="width: 300px; height: 500px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/D1366012-6A0C-4D0E-A57A-0EE0C6781B8F.jpeg" alt="img" class="category-img">
				 
				 <img style="width: 300px; height: 500px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/188F1A6B-E761-4854-8161-C397EF801C28.jpeg" alt="img" class="category-img">
				 
				 <img style="width: 300px; height: 500px; border: 4px solid #575D63; padding: 10px; margin: 20px;" src="https://spaces.ilfen.co/assets/image/produk/C9CE8265-35B1-45BB-98BC-5DF287540258.jpeg" alt="img" class="category-img">
				 			  </td>
            </tr><br>
			<tr> <td><center><button><a href="#" class="active"><input type="submit" name="Submit" value="View All"></a></button> </center></td></tr>
    </table>
      	
      	
  </div>
</div>
<!-- end content2 -->
    <!--  footer -->
    <footr>
      <div class="footer ">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <form class="contact_bg">
            <div class="row">
              
            </div>
            </form>

            </div>
            
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
              <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                  <div class="address">
                    <ul class="loca">
                      <li>
                        <a href="#"><img src="icon/loc.png" alt="#" /></a>Jl. Medan-Binjai Km 10.8
                   
                        <li>
                          
                            <a href="#"><img src="icon/call.png" alt="#" /></a>+6281260710829 </li>
                          <li>
                            <a href="#"><img src="icon/email.png" alt="#" /></a>szyangelfery1512@gmail.com </li>
                          </ul>
                         

                        </div>
                      </div>
                       <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                           <ul class="social_link">
                            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                          </ul>
                       </div>
                    </div>
                  </div>

                </div>

              </div>
               <div class="container">
              <div class="copyright">
               
                  <p>Copyright 2021 All Right Reserved Ferry</a></p>
                </div>
              </div>
            </div>
          </footr>
          <!-- end footer -->
          <!-- Javascript files-->
          <script src="js/jquery.min.js"></script>
          <script src="js/popper.min.js"></script>
          <script src="js/bootstrap.bundle.min.js"></script>
          <script src="js/jquery-3.0.0.min.js"></script>
          <script src="js/plugin.js"></script>
          <!-- sidebar -->
          <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
          <script src="js/custom.js"></script>
          <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>




</body>

</html>